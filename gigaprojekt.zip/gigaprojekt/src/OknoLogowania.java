import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class OknoLogowania extends JFrame {
    private JPanel panel;
    private JLabel label;
    private JTextField text;
    private JPasswordField password;
    private JButton loginButton;

    public OknoLogowania() {
        super("Logowanie");
        setSize(300, 200);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        panel = new JPanel();
        panel.setLayout(null);

        label = new JLabel("Login:");
        text = new JTextField();
        password = new JPasswordField();
        loginButton = new JButton("Zaloguj");

        label.setBounds(50, 20, 50, 30);
        text.setBounds(100, 20, 150, 30);
        password.setBounds(100, 60, 150, 30);
        loginButton.setBounds(100, 100, 100, 30);

        panel.add(label);
        panel.add(text);
        panel.add(password);
        panel.add(loginButton);
        add(panel);
        setVisible(true);

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String login = text.getText();
                String haslo = new String(password.getPassword());
                try {
                    if (sprawdzPlik(login, haslo)) {
                        System.out.println("Zalogowano!");
                        // Tutaj możesz dodać kod obsługujący poprawne logowanie
                    } else {
                        System.out.println("Błędny login lub hasło!");
                    }
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        });
    }

    private boolean sprawdzPlik(String login, String haslo) throws IOException {
        FileReader fileReader = new FileReader("Login_Haslo.txt");
        BufferedReader br = new BufferedReader(fileReader);
        String line;

        while ((line = br.readLine()) != null) {
            String[] parts = line.split(" ");
            String storedLogin = parts[0];
            String storedPassword = parts[1];

            if (storedLogin.equals(login) && storedPassword.equals(haslo)) {
                br.close();
                return true;
            }
        }

        br.close();
        return false;
    }
}
